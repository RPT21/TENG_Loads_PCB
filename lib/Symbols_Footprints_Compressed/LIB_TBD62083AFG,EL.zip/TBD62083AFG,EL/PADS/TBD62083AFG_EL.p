*PADS-LIBRARY-PART-TYPES-V9*

TBD62083AFG_EL SOIC127P1030X245-18N I TRX 7 1 0 0 0
TIMESTAMP 2026.07.28.16.38.14
"Mouser Part Number" 757-TBD62083AFGEL
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Toshiba/TBD62083AFGEL?qs=fSnNYG2PaKIrAovmru5jNA%3D%3D
"Manufacturer_Name" Toshiba
"Manufacturer_Part_Number" TBD62083AFG,EL
"Description" Gate Drivers DMOS Transistor Array 7-CH, 50V/0.5A
"Datasheet Link" https://componentsearchengine.com/Datasheets/1/TBD62083AFG,EL.pdf
"Geometry.Height" 2.45mm
GATE 1 18 0
TBD62083AFG_EL
1 0 U I1
2 0 U I2
3 0 U I3
4 0 U I4
5 0 U I5
6 0 U I6
7 0 U I7
8 0 U I8
9 0 U GND
18 0 U O1
17 0 U O2
16 0 U O3
15 0 U O4
14 0 U O5
13 0 U O6
12 0 U O7
11 0 U O8
10 0 U COMMON

*END*
*REMARK* SamacSys ECAD Model
329270/1557983/2.50/18/3/Transistor
