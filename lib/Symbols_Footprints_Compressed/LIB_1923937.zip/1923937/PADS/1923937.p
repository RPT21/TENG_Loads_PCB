*PADS-LIBRARY-PART-TYPES-V9*

1923937 1923937 I CON 7 1 0 0 0
TIMESTAMP 2026.07.28.13.01.55
"Mouser Part Number" 651-1923937
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Phoenix-Contact/1923937?qs=6i0QExrCb7MxQ2Gx%2FnBU8w%3D%3D
"Manufacturer_Name" Phoenix Contact
"Manufacturer_Part_Number" 1923937
"Description" MSTBA 2,5 HC/ 9-G-5,08 - PCB headers, nominal cross section: 2.5 mm<sup>2</sup>, color: green, nominal current: 16 A (see derating curve), rated voltage (III/2): 320 V, contact surface: Sn, contact connection type: Pin, number of potentials: 9, number of rows: 1, number of positions: 9, number of connections: 9, product range: MSTBA 2,5 HC/..-G, pitch: 5.08 mm, mounting: Wave soldering, pin layout: Linear pinning, solder pin [P]: 3.23 mm, number of solder pins per potential: 1, plug-in system: COMBICON MSTB
"Datasheet Link" https://www.phoenixcontact.com/en-us/products/pcb-header-mstba-25-hc-9-g-508-1923937?type=pdf
"Geometry.Height" 8.72mm
GATE 1 9 0
1923937
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9

*END*
*REMARK* SamacSys ECAD Model
452420/1557983/2.50/9/2/Connector
