*PADS-LIBRARY-PART-TYPES-V9*

74HC238D_653 74HC238D653 I ANA 7 1 0 0 0
TIMESTAMP 2026.07.28.16.42.46
"Mouser Part Number" 771-74HC238D-T
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Nexperia/74HC238D653?qs=P62ublwmbi8dvjtlyD3gOA%3D%3D
"Manufacturer_Name" Nexperia
"Manufacturer_Part_Number" 74HC238D,653
"Description" 74HC(T)238 - 3-to-8 line decoder/demultiplexer@en-us
"Datasheet Link" https://assets.nexperia.com/documents/data-sheet/74HC_HCT238.pdf
"Geometry.Height" 1.75mm
GATE 1 16 0
74HC238D_653
1 0 U A0
2 0 U A1
3 0 U A2
4 0 U \E1
5 0 U \E2
6 0 U E3
7 0 U Y7
8 0 U GND
9 0 U Y6
10 0 U Y5
11 0 U Y4
12 0 U Y3
13 0 U Y2
14 0 U Y1
15 0 U Y0
16 0 U VCC

*END*
*REMARK* SamacSys ECAD Model
631014/1557983/2.50/16/2/Integrated Circuit
